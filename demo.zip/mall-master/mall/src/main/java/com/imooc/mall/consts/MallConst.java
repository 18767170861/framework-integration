package com.imooc.mall.consts;

/**
 * Created by 廖师兄
 */
public class MallConst {
	public static final String CURRENT_USER = "currentUser";

	public static final Integer ROOT_PARENT_ID = 0;
}
